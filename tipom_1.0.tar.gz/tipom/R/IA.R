IA <-
  function(length, width) {
    ia <- length / width
    ia
  }


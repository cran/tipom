MS <-
  function(length, width) {
    ms <- length + width
    ms
  }
